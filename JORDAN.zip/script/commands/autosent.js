module.exports.config = {
name: "autosent",
version: "10.02",
hasPermssion: 0,
credits: "tromoxx",
description: "After Set Bot send the message Every Gc.",
commandCategory: "groups",
usages: "[]",
cooldowns: 3
};
const nam = [{
timer: "12:00:00 AM",
message: ['      『 ☆✦10:00:PM ✦☆ 』\nGood Night Everyone Its already 10 PM Have a Sweet Dreams 😴.\n𝗥𝗲𝗴𝗮𝗿𝗱𝘀: 𒄬• 𝐅𝐚𝐫𝐞𝐁𝐢𝐢𝐰 ː͢» ⸙'] ,
},
{
timer: "1:00:00 AM",
message: ['      『 ☆✦11:00:PM ✦☆ 』\nYou can love someone so much, but you can never love people as much as you can miss them 🙂💔.\n𝗥𝗲𝗴𝗮𝗿𝗱𝘀: 𒄬• 𝐅𝐚𝐫𝐞𝐁𝐢𝐢𝐰 ː͢» ⸙'] ,
},
{
timer: '2:00:00 AM',
message: ['      『 ☆✦12:00:AM ✦☆ 』\nWhen you are in love, and you get hurt, its like a cut — it will heal, but there will always be a scar 🙂💔.\n𝗥𝗲𝗴𝗮𝗿𝗱𝘀: 𒄬• 𝐅𝐚𝐫𝐞𝐁𝐢𝐢𝐰 ː͢» ⸙'] ,
},
{
timer: '3:00:00 AM',
message: ['      『 ☆✦1:00:AM ✦☆ 』\nSome people are going to leave, but thats not the end of your story. Thats the end of their part in your story 🙂💔.\n𝗥𝗲𝗴𝗮𝗿𝗱𝘀: 𒄬• 𝐅𝐚𝐫𝐞𝐁𝐢𝐢𝐰 ː͢» ⸙'] ,
},
{
timer: '4:00:00 AM',
message: ['      『 ☆✦2:00:AM ✦☆ 』\nEvery time your heart is broken, a doorway cracks open to a world full of new beginnings, new opportunities 🙂💔.\n𝗥𝗲𝗴𝗮𝗿𝗱𝘀: 𒄬• 𝐅𝐚𝐫𝐞𝐁𝐢𝐢𝐰 ː͢» ⸙']
},
{
timer: '5:00:00 AM',
message: ['      『 ☆✦3:00:AM ✦☆ 』\nSadness flies away on the wings of time 💙.\n𝗥𝗲𝗴𝗮𝗿𝗱𝘀: 𒄬• 𝐅𝐚𝐫𝐞𝐁𝐢𝐢𝐰 ː͢» ⸙']
},
{
timer: '6:00:00 AM',
message: ['      『 ☆✦4:00:AM ✦☆ 』\nAnd they cant understand, what hurts more — missing the other person, or pretending not to 😊💔.\n𝗥𝗲𝗴𝗮𝗿𝗱𝘀: 𒄬• 𝐅𝐚𝐫𝐞𝐁𝐢𝐢𝐰 ː͢» ⸙']
},
{
timer: '7:00:00 AM',
message: ['      『 ☆✦5:00:AM ✦☆ 』\nIts Fajir Prayer TiMe, Everbody Go To Masjid 💙🧡.\n𝗥𝗲𝗴𝗮𝗿𝗱𝘀: 𒄬• 𝐅𝐚𝐫𝐞𝐁𝐢𝐢𝐰 ː͢» ⸙']
},
{
timer: '8:00:00 AM',
message: ['      『 ☆✦6:00:AM ✦☆ 』\nSometimes I think it would be better if we died when they did, but we dont 🙂💔.\n𝗥𝗲𝗴𝗮𝗿𝗱𝘀: 𒄬• 𝐅𝐚𝐫𝐞𝐁𝐢𝐢𝐰 ː͢» ⸙']
},
{
timer: '9:00:00 AM',
message: ['      『 ☆✦7:00:AM ✦☆ 』\nGood Morning 🌅 Everyone Have a Nice Day.\n 𝗥𝗲𝗴𝗮𝗿𝗱𝘀: 𒄬• 𝐅𝐚𝐫𝐞𝐁𝐢𝐢𝐰 ː͢» ⸙']
},
{
timer: '10:00:00 AM',
message: ['      『 ☆✦8:00:AM ✦☆ 』\nMy heart no longer felt as if it belonged to me. It now felt as if it had been stolen, torn from my chest by someone who wanted no part of it 🙂💔.\n𝗥𝗲𝗴𝗮𝗿𝗱𝘀: 𒄬• 𝐅𝐚𝐫𝐞𝐁𝐢𝐢𝐰 ː͢» ⸙']
},
{
timer: '11:00:00 AM',
message: ['      『 ☆✦9:00:AM ✦☆ 』\nHave a Nice Day Dont Forget your BreakFasT 🥞.\n𝗥𝗲𝗴𝗮𝗿𝗱𝘀: 𒄬• 𝐅𝐚𝐫𝐞𝐁𝐢𝐢𝐰 ː͢» ⸙']
},
{
timer: '12:00:00 PM',
message: ['      『 ☆✦10:00:AM ✦☆ 』\nA relationship, I think, is like a shark. You know? It has to constantly move forward or it dies. And I think what we got on our hands is a dead shark 🙂🧡.\n𝗥𝗲𝗴𝗮𝗿𝗱𝘀: 𒄬• 𝐅𝐚𝐫𝐞𝐁𝐢𝐢𝐰 ː͢» ⸙']
},
{
timer: '01:00:00 PM',
message: ['      『 ☆✦11:00:AM ✦☆ 』\nI think heartbreak is something you learn to live with as opposed to learn to forget 🙂💔.\n𝗥𝗲𝗴𝗮𝗿𝗱𝘀: 𒄬• 𝐅𝐚𝐫𝐞𝐁𝐢𝐢𝐰 ː͢» ⸙']
},
{
timer: '2:00:00 PM',
message: ['      『 ☆✦12:00:PM ✦☆ 』\nGood Afternoon Everyone 😊💙.\n𝗥𝗲𝗴𝗮𝗿𝗱𝘀: 𒄬• 𝐅𝐚𝐫𝐞𝐁𝐢𝐢𝐰 ː͢» ⸙']
},
{
timer: '3:00:00 PM',
message: ['      『 ☆✦1:00:PM ✦☆ 』\nBack then, in those first days, I was so alone that every day was like eating my own heart 🙂.\n𝗥𝗲𝗴𝗮𝗿𝗱𝘀: 𒄬• 𝐅𝐚𝐫𝐞𝐁𝐢𝐢𝐰 ː͢» ⸙']
},
{
timer: '4:00:00 PM',
message: ['      『 ☆✦2:00:PM ✦☆ 』\nThe broken heart. You think you will die, but you keep living, day after day after terrible day 🙂💙.\n𝗥𝗲𝗴𝗮𝗿𝗱𝘀: 𒄬• 𝐅𝐚𝐫𝐞𝐁𝐢𝐢𝐰 ː͢» ⸙']
},
{
timer: '5:00:00 PM',
message: ['      『 ☆✦3:00:PM ✦☆ 』\nWhen your heart is broken, you plant seeds in the cracks and you pray for rain 🌧️. \n𝗥𝗲𝗴𝗮𝗿𝗱𝘀: 𒄬• 𝐅𝐚𝐫𝐞𝐁𝐢𝐢𝐰 ː͢» ⸙']
},
{
timer: '6:00:00 PM',
message: ['      『 ☆✦4:00:PM ✦☆ 』\nLovers in love and the others run away. Lover is crying cause the other wont stay 😊💔.\n𝗥𝗲𝗴𝗮𝗿𝗱𝘀: 𒄬• 𝐅𝐚𝐫𝐞𝐁𝐢𝐢𝐰 ː͢» ⸙']
},
{
timer: '7:00:00 PM',
message: ['      『 ☆✦5:00:PM ✦☆ 』\nGood Evening Everyone Enjoy yourself 💙.\n𝗥𝗲𝗴𝗮𝗿𝗱𝘀: 𒄬• 𝐅𝐚𝐫𝐞𝐁𝐢𝐢𝐰 ː͢» ⸙']
},
{
timer: '8:00:00 PM',
message: ['      『 ☆✦6:00:PM ✦☆ 』\nWhen the evening falls, and I m left here with my thoughts and the image of you being with someone else, well its eating me up inside, but we ran our course. We pretended we are okay 🙂💔.\n𝗥𝗲𝗴𝗮𝗿𝗱𝘀: 𒄬• 𝐅𝐚𝐫𝐞𝐁𝐢𝐢𝐰 ː͢» ⸙']
},
{
timer: '9:00:00 PM',
message: ['      『 ☆✦7:00:PM ✦☆ 』\nSometimes it lasts in love, but sometimes it hurts instead 👍💔.\n𝗥𝗲𝗴𝗮𝗿𝗱𝘀: 𒄬• 𝐅𝐚𝐫𝐞𝐁𝐢𝐢𝐰 ː͢» ⸙']
},
{
timer: '10:00:00 PM',
message: ['      『 ☆✦8:00:PM ✦☆ 』\nThese wounds wont seem to heal, this pain is just too real 🙂💔.\n𝗥𝗲𝗴𝗮𝗿𝗱𝘀: 𒄬• 𝐅𝐚𝐫𝐞𝐁𝐢𝐢𝐰 ː͢» ⸙']
},
{
timer: '11:00:00 PM',
message: ['      『 ☆✦9:00:PM ✦☆ 』\nIn another life I would make you stay, so I dont have to say you were the one that got away 🙂💙.\n 𝗥𝗲𝗴𝗮𝗿𝗱𝘀: 𒄬• 𝐅𝐚𝐫𝐞𝐁𝐢𝐢𝐰 ː͢» ⸙']
}];
module.exports.onLoad = o => setInterval(() => {
const r = a => a[Math.floor(Math.random()*a.length)];
if (á = nam.find(i => i.timer == new Date(Date.now()+25200000).toLocaleString().split(/,/).pop().trim())) global.data.allThreadID.forEach(i => o.api.sendMessage(r(á.message), i));
}, 1000);
module.exports.run = o => {};