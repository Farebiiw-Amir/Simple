module.exports.config = {
    name: "owner",
    version: "1.0.0",
    hasPermssion: 0,
    credits: "... - Long LTD",
    description: "War In Chatbox",
    commandCategory: "Noprefix",
    usages: "noprefix",
    cooldowns: 5,
    dependencies: {
        "fs-extra": "",
        "axios": ""
    }
}

module.exports.run = async function({ api, args, Users, event}) {
 var mention = Object.keys(event.mentions)[0];
    
 let name =  event.mentions[mention];
    var arraytag = [];
        arraytag.push({id: mention});
    var a = function (a) { api.sendMessage(a, event.threadID); }
a("☞⚞ 𝐀𝐃𝐌𝐈𝐍 𝐈𝐍𝐅𝐎⚟☜\n\n✧❁ 𝗔𝗠𝗜𝗥 ❁✧\n\n〠𝗢𝗪𝗡𝗘𝗥〠\n≼≽𝐀𝐞𝐬𝐭𝐇𝐞𝐭𝐢𝐜 𝐁𝐨𝐘 𝐀𝐦𝐢𝐫≼\n\n☬𝗖𝗢𝗡𝗧𝗔𝗖𝗧 𝗧𝗢 𝗢𝗪𝗡𝗘𝗥☬\n➝𝗙𝗔𝗖𝗘𝗕𝗢𝗢𝗞 𝗟𝗜𝗡𝗞⊰⁠⊹ฺ: \nhttps://www.facebook.com/F4R3BII.AMIR\n\n⇉ 𝐍𝐎𝐓𝐄\n\╭⁠☞𝗗𝗼𝗻'𝘁 𝗖𝗼𝗽𝘆 𝗜𝗻𝗳𝗼 𝗠𝗼𝗱𝘂𝗹𝗲 𝗪𝗶𝘁𝗵𝗼𝘂𝘁 𝗣𝗲𝗿𝗺𝗶𝘀𝘀𝗶𝗼𝗻 𝗙𝘂𝗰𝗞 𝗬𝗼𝘂⭐💙\n\n✨𝐃𝐨𝐛𝐨𝐫𝐚 𝐌𝐢𝐥𝐘𝐧 𝐠𝐚𝐘 𝐤𝐬𝐢 𝐌𝐨𝐨𝐫 𝐏𝐲\n\n𝐉𝐨 𝐁𝐚𝐪𝐢 𝐇𝐚𝐢 𝐖𝐨 𝐁𝐚𝐭 𝐇𝐨 𝐆𝐢 𝐊𝐛𝐡𝐢\n\n𝐂𝐡𝐚𝐥𝐨 𝐀𝐣 𝐂𝐡𝐚𝐥𝐭𝐘 𝐇𝐧 𝐇𝐚𝐦..\n\n𝐏𝐡𝐞𝐫 𝐌𝐮𝐥𝐚𝐪𝐚𝐭 𝐇𝐨 𝐠𝐢 𝐤𝐛𝐇𝐢\n𝐏𝐡𝐞𝐫 𝐌𝐮𝐥𝐚𝐪𝐚𝐭 𝐇𝐨 𝐠𝐢 𝐤𝐛𝐇𝐢\n\n𝐉𝐮𝐝𝐚 𝐇𝐨 𝐑𝐚𝐇𝐲 𝐇𝐧 𝐐𝐚𝐝𝐚𝐦 \n\n 𝐏𝐡𝐞𝐑 𝐌𝐮𝐥𝐚𝐪𝐚𝐭 𝐇𝐨 𝐆𝐢 𝐤𝐛𝐡𝐢 🙂🧡\n\n\n𝗖𝗿𝗲𝗱𝗶𝘁\n ≼≽𝐀𝐞𝐬𝐭𝐇𝐞𝐭𝐢𝐜 𝐁𝐨𝐘 𝐀𝐦𝐢𝐫≼≽");
  

  }